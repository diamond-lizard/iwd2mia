Icewind Dale II
README-BBRNGOC.txt
Version: 1.0
Last Mod Date: 10/27/06
Author: Brendan Bellina
Mailto: bbellina@alumni.nd.edu

This installs into your IWD2 override directory the item(s):
BBRNGOC - Ring of Over-Compensation

Requirements:

Icewind Dale II for Microsoft Windows is required.

A utility to extract zipped archives. Two shareware options are WinZip and 7-Zip.


Installation instructions:

Extract the contents of the Zipped file into your IWD2 main directory. This is the
directory that contains the override directory and is normally:
        C:\Program Files\Black Isle\Icewind Dale II\

This will create the following items in the Icewind Dale II directory:
README-BBRNGOC.txt -- the file you are reading
setup-BBRNGOC.exe -- the program used to install and uninstall the item
setup-BBRNGOC.tp2 -- the file that tells the installer program what to do
BBRNGOC -- a directory containing the files used by the installer and a backup subdirectory

Run (click on) "setup-BBRNGOC.exe" and follow the on-screen instructions.

The file WeiDU.log will be created/updated to indicate that the item has been installed.

To give the item to a character you can use a game editor such as DaleKeeper2 or use
the in-game Cheat Console.

For instructions on how to use DaleKeeper2 see the DaleKeeper2 instructions.

To enable the in-game Cheat Console launch the Icewind Dale II Configuration Utility,
go to the Game tab, checkmark the Game Settings: Enable Cheat Console option, and click OK.

To use the in-game Cheat Console to add the item to inventory
- load a game
- press Ctrl-Tab to open the Cheat Console window
- type the following command into the Cheat Console window:
ctrlaltdelete:createitem("BBRNGOC",1)
- press enter
- press the Esc key to exit the Cheat Console

The item should now be in the inventory of your lead character.


Special thanks to:

The game designers at Black Isle studios.
The Black Isle artist who created the BAM files.
Westley Weimer for his excellent WeiDU utility used for the install.
Jon Olav Hauglid, author of the NearInfinity utility used to create the item.
Igor Pavlov, author of 7-Zip.
Gary Gygax for creating Dungeons & Dragons.

-- End of file --