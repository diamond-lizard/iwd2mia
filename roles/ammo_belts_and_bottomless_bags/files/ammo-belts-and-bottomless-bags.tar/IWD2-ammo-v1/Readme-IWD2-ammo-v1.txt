Ammo Belts and Bottomless Bags (v.1)
Created by Tioma (Igor Potemine, Ipotemine@aol.com, http://pageperso.aol.fr/Ipotemine)

This pack contains :

1. Bottomless bags

- All bags (portable item containers) can now contain up to 16^4-1=65535 items.

2. Ammo belts

- An ammo belt can contain up to 65535 arrows, boltes, bullets and darts.

3. Ammo belt available in Henghelm, Gallaway, Artemus, Beodaewn, Tahvo and/or Conlan stores.

- An ammo belt will be avialable in these stores if you did't visit them before. 
If you already visited all these stores, you can use CLUAConsole or DaleKeeper2 to get an ammo belt directly.
