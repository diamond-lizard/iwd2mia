Icewind Dale II
README-BBBKBG.txt
Version: 1.0
Last Mod Date: 9/25/04
Author: Brendan Bellina
Mailto: bbellina@alumni.nd.edu

This installs into your IWD2 override directory the item(s):
BBBKBG1 - Book Bag
BBBKBG2 - Book Bag
BBBKBG3 - Book Bag
BBBKBG4 - Book Bag
BBBKBG5 - Book Bag
BBBKBG6 - Book Bag
BBBKBG7 - Book Bag
BBBKBG8 - Book Bag
BBBKBG9 - Book Bag

Requirements:

Icewind Dale II for Microsoft Windows is required.

A utility to extract zipped archives. Two shareware options are WinZip and 7-Zip.


Installation instructions:

Extract the contents of the Zipped file into your IWD2 main directory. This is the
directory that contains the override directory and is normally:
        C:\Program Files\Black Isle\Icewind Dale II\

This will create the following items in the Icewind Dale II directory:
README-BBBKBG.txt -- the file you are reading
setup-BBBKBG.exe -- the program used to install and uninstall the item
setup-BBBKBG.tp2 -- the file that tells the installer program what to do
BBBKBG -- a directory containing the files used by the installer and a backup subdirectory

Run (click on) "setup-BBBKBG.exe" and follow the on-screen instructions.

The file WeiDU.log will be created/updated to indicate that the item has been installed.

To give the item to a character you can use a game editor such as DaleKeeper2 or use
the in-game Cheat Console.

For instructions on how to use DaleKeeper2 see the DaleKeeper2 instructions.

To enable the in-game Cheat Console launch the Icewind Dale II Configuration Utility,
go to the Game tab, checkmark the Game Settings: Enable Cheat Console option, and click OK.

To use the in-game Cheat Console to add the item to inventory
- load a game
- press Ctrl-Tab to open the Cheat Console window
- type any of the following commands into the Cheat Console window
  (note: DO NOT create multiple copies of the same Book Bag, each is a unique container):
ctrlaltdelete:createitem("BBBKBG1",1)
ctrlaltdelete:createitem("BBBKBG2",1)
ctrlaltdelete:createitem("BBBKBG3",1)
ctrlaltdelete:createitem("BBBKBG4",1)
ctrlaltdelete:createitem("BBBKBG5",1)
ctrlaltdelete:createitem("BBBKBG6",1)
ctrlaltdelete:createitem("BBBKBG7",1)
ctrlaltdelete:createitem("BBBKBG8",1)
ctrlaltdelete:createitem("BBBKBG9",1)
- press enter
- press the Esc key to exit the Cheat Console

The item should now be in the inventory of your lead character.

Note that the standard books in IWD2 are not type "Books" as you might think,
but instead are type "Misc".  Therefore in order for the book bags to actually
hold books they are set up to allow both items of type "Misc" and items of type "Books".
The bags can also hold some other types.


Special thanks to:

The game designers at Black Isle studios.
The Black Isle artist who created the BAM files.
Westley Weimer for his excellent WeiDU utility used for the install.
Jon Olav Hauglid, author of the NearInfinity utility used to create the item.
Igor Pavlov, author of 7-Zip.
Gary Gygax for creating Dungeons & Dragons.


-- End of file --