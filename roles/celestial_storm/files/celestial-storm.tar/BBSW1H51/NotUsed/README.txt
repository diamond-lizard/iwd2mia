These are the files from BG2 for the 3D effect when
Celestial Fury strikes successfully.  It would have been great
to use this effect but I could not determine a way to import
it into the IWD2 item.  If anyone knows how please let me know.

Brendan Bellina